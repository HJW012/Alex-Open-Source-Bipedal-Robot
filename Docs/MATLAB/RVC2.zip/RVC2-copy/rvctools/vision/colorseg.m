%COLORSEG  Color image segmentation using k-means
%
% THIS FUNCTION IS DEPRECATED, USE COLORKMEANS INSTEAD
%
% Notes::
% - deprecated.  Use COLORKMEANS instead.
%
% See also COLORKMEANS.

function [a,b] = colorseg(x, y, z)

    error('Deprecated: use colorkmeans() instead');
